package com.lambda;

import java.util.List;
import java.util.stream.Collectors;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lambda.model.Employee;

public class GetAllEmployees {
	
	public APIGatewayProxyResponseEvent getAllEmployees(APIGatewayProxyRequestEvent request)
			throws JsonMappingException, JsonProcessingException {
	
		AmazonDynamoDB dynamodb = AmazonDynamoDBClientBuilder.defaultClient();
		
		ScanResult scanResult = dynamodb.scan(new ScanRequest().withTableName(System.getenv("EMPLOYEE")));
		
		List<Employee> empList = scanResult.getItems()
				.stream()
				.map(item -> new Employee(Integer.parseInt(item.get("id").getN()),item.get("name").getS()))
				.collect(Collectors.toList());
		
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonOutput = objectMapper.writeValueAsString(empList);
		
		return new APIGatewayProxyResponseEvent().withStatusCode(200).withBody(jsonOutput);
	}

}
