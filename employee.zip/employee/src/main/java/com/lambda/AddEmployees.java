package com.lambda;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lambda.model.Employee;

public class AddEmployees {

	static String forumTableName = System.getenv("EMPLOYEE");
	static String threadTableName = System.getenv("DUMMY_TABLE") ;

	public APIGatewayProxyResponseEvent addEmployees(APIGatewayProxyRequestEvent request)
			throws JsonMappingException, JsonProcessingException {

		System.out.println("Start");

//		List<Employee> empList = (ArrayList<Employee>) objectMapper.readValue(request.getBody(), ArrayList.class); 

//		System.out.println("Request: GetBody: ToString: "+request.getBody().toString());

//		String json = objectMapper.readValue(request.toString(), String.class);
//		System.out.println("json: "+ json);
//		

//		LinkedHashMap<String, String> map = objectMapper.readValue(request.getBody(), LinkedHashMap.class);
//		
//		for(Map.Entry<String, String> entry : map.entrySet() ) {
//			System.out.println(entry.getKey());
//			System.out.println(entry.getValue());
//		}

		ObjectMapper objectMapper = new ObjectMapper();
		List<Employee> empList = objectMapper.readValue(request.getBody(), new TypeReference<List<Employee>>() {});
		
		System.out.println("ObjectMapper Created and converted into List ");

		for (Employee emp : empList) {
			System.out.println(emp);
		}
		System.out.println("End for");

		DynamoDB dynamodb = new DynamoDB(AmazonDynamoDBClientBuilder.defaultClient());
		Table table = dynamodb.getTable(System.getenv("EMPLOYEE"));
		System.out.println("Dynamodb and Table Loaded");

		TableWriteItems forumTableWriteItems = new TableWriteItems(forumTableName);
		for (Employee emp : empList) {
			forumTableWriteItems
					.addItemToPut(new Item().withPrimaryKey("id", emp.getId()).withString("name", emp.getName()));
		}
		System.out.println("Employees added to forum table");
		TableWriteItems threadTableWriteItems = new TableWriteItems(threadTableName);
		threadTableWriteItems.addItemToPut(new Item().withPrimaryKey("id", 1).withString("name","nikhil"));

		System.out.println("Making the request.");
		try {
			BatchWriteItemOutcome outcome = dynamodb.batchWriteItem(forumTableWriteItems, threadTableWriteItems);
			System.out.println("Batch written command executed");

			do {

				Map<String, List<WriteRequest>> unprocessedItems = outcome.getUnprocessedItems();

				if (outcome.getUnprocessedItems().size() == 0) {
					System.out.println("No unprocessed items found");
				} else {
					System.out.println("Retrieving the unprocessed items");
					outcome = dynamodb.batchWriteItemUnprocessed(unprocessedItems);
				}

			} while (outcome.getUnprocessedItems().size() > 0);
			System.out.println("End do while");
		} catch (Exception e) {
			System.out.println("Exception : ");
			e.printStackTrace();
		}
		return new APIGatewayProxyResponseEvent().withStatusCode(200).withBody("Employees added successfully");

	}

}


