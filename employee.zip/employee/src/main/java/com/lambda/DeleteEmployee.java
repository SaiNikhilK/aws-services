package com.lambda;

import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DeleteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent.ProxyRequestContext;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DeleteEmployee {
	
	public APIGatewayProxyResponseEvent deleteEmployee(APIGatewayProxyRequestEvent request)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		
		Map<String, String> pathParams = request.getPathParameters();
		int data = Integer.parseInt(pathParams.get("id"));
		
		DynamoDB dynamodb = new DynamoDB(AmazonDynamoDBClientBuilder.defaultClient());
		Table table = dynamodb.getTable(System.getenv("EMPLOYEE"));
	
		DeleteItemOutcome outcome = table.deleteItem("id", data);
		System.out.println(outcome.toString());
		
		return new APIGatewayProxyResponseEvent().withStatusCode(200).withBody("Delete Successful");
	}

}
