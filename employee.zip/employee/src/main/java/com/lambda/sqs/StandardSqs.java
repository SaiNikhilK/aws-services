package com.lambda.sqs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.MessageAttribute;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.lambda.model.Employee;

public class StandardSqs {
	
	public void addEmployeesSqs(SQSEvent event) {
		
		List<Employee> empList = new ArrayList<Employee>();
		
		for(SQSMessage msg : event.getRecords()) {
			
			Employee emp = new Employee();
			Map<String, MessageAttribute> attributes = msg.getMessageAttributes();
			
			for(Map.Entry<String, MessageAttribute> attribute : attributes.entrySet()) {
				
				System.out.println("Key: "+attribute.getKey());
				emp.setId(Integer.parseInt(attribute.getKey()));
				
				System.out.println("Value: "+attribute.getValue().getStringValue());
				emp.setName(attribute.getValue().getStringValue());
				
				empList.add(emp);
				
				DynamoDB dynamodb = new DynamoDB(AmazonDynamoDBClientBuilder.defaultClient());
				Table table = dynamodb.getTable(System.getenv("EMPLOYEE"));
				Item item = new Item().withPrimaryKey("id",emp.getId()).withString("name", emp.getName());
				table.putItem(item);
			}
			
			
		}
	}

}
